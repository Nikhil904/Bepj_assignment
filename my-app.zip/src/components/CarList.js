import React from 'react'
import CarTable from './CarTable'

const CarList = () => {
  return (
    <div>
      <CarTable/>
    </div>
  )
}

export default CarList
